# Roblox MOD BR — projeto Android

Aplicativo Android independente com identidade visual preta/vermelha, editor Luau local, console, gerenciamento de arquivos e configurações. Sem key, sem anúncios obrigatórios.

## O que está implementado no código-fonte
- Editor de código Luau e execução no runtime local Luau (não dentro do cliente Roblox).
- Console com saída de `print` e erros do compilador/runtime.
- Copiar e limpar texto.
- Salvar scripts no armazenamento privado do aplicativo.
- Abrir/importar e exportar scripts por seletor de arquivos Android.
- Tela de scripts com abrir, renomear e excluir.
- Configuração de tema claro/escuro e tela de informações.
- Interface Android com botões grandes.

## Limites
Este app NÃO é uma versão modificada do cliente Roblox e não injeta código em Roblox. Não fornece APIs Roblox como `game`, `workspace`, `Instance` ou `task`. O menu controla apenas o ambiente de teste local. Para controlar funcionalidades dentro de um jogo Roblox, implemente-as no seu próprio jogo no Roblox Studio usando scripts e RemoteEvents autorizados.

## Compilar
Requisitos: Android Studio, JDK, Android SDK 35, NDK e CMake 3.22.1. A primeira compilação precisa de internet para baixar o código-fonte do Luau.

1. Extraia o ZIP e abra a pasta `RobloxMODBR` no Android Studio.
2. Instale Android SDK 35, NDK (Side by side) e CMake pelo SDK Manager.
3. Sincronize o Gradle.
4. Use **Build > Build APK(s)**.
5. APK debug esperado, se a compilação concluir: `app/build/outputs/apk/debug/app-debug.apk`.

## Estado de verificação
O pacote contém o código-fonte, mas não foi compilado nem testado em um dispositivo nesta sessão. Portanto, não há APK compilado anexado nem alegação de testes bem-sucedidos. Valide a compilação e teste as funções em um dispositivo Android antes de distribuir.

## Gerar o APK pelo GitHub (também pelo celular)
O projeto inclui `.github/workflows/android.yml`, configurado para usar JDK 17, Gradle 8.9, Android SDK 35, NDK e CMake. Para gerar o instalador: 

1. No GitHub, crie um repositório novo e vazio.
2. Envie os arquivos e pastas deste projeto para a raiz do repositório (não envie a pasta ZIP dentro do repositório; os arquivos do projeto precisam ficar na raiz).
3. Abra **Actions** e selecione **Build Android APK**.
4. Toque em **Run workflow** e espere o processo terminar com sucesso.
5. Abra a execução concluída e baixe **Roblox-MOD-BR-debug-apk** em **Artifacts**. Dentro do arquivo de artefato estará `app-debug.apk`.
6. No Android, abra o APK baixado e, se o sistema pedir, permita a instalação para esse aplicativo de origem. Instale apenas se confiar no arquivo.

O GitHub só gera o APK depois que você enviar o projeto e iniciar o workflow. Esta pasta contém código-fonte, não um APK já compilado. A compilação e o funcionamento ainda precisam ser verificados no GitHub e no aparelho.
