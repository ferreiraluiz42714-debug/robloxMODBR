package br.deltamobile

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var console: TextView
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private var pendingText = ""
    private var dark = true
    private var currentFile: File? = null
    private val red = Color.rgb(255, 35, 55)
    private val bg get() = if (dark) Color.rgb(10, 10, 13) else Color.rgb(245, 245, 248)
    private val panel get() = if (dark) Color.rgb(24, 24, 30) else Color.rgb(225, 225, 232)
    private val fg get() = if (dark) Color.WHITE else Color.BLACK

    external fun runLuau(code: String): String
    companion object { init { System.loadLibrary("deltabr") } }

    private val createFile = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) writeUri(uri, pendingText)
    }
    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { editor.setText(it.readText()) }
            currentFile = null
            status.text = "Arquivo importado"
        } catch (e: Exception) { log("Erro ao abrir: ${e.message}") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10,10,13); window.navigationBarColor = Color.rgb(10,10,13)
        showEditor()
    }

    private fun showEditor() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 12); setBackgroundColor(bg) }
        root.addView(TextView(this).apply {
            text = "▲  ROBLOX MOD BR"; textSize = 23f; setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD; setPadding(0, 4, 0, 4)
        })
        root.addView(TextView(this).apply {
            text = "MOD MENU • LUAU • SEM KEY • TESTE LOCAL"; textSize = 11f; setTextColor(fg); setPadding(0,0,0,10)
        })
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav.addView(button("Scripts", panel) { showFiles() }, weightParams())
        nav.addView(button("Configurações", panel) { showSettings() }, weightParams())
        root.addView(nav)
        editor = EditText(this).apply {
            setText("-- Delta BR Mobile\nprint(\"Olá do Luau!\")\n")
            setTextColor(fg); setHintTextColor(Color.GRAY); setHint("Escreva seu código Luau...")
            textSize = 14f; typeface = Typeface.MONOSPACE; gravity = android.view.Gravity.TOP or android.view.Gravity.START
            setPadding(12,12,12,12); setBackgroundColor(panel); minLines = 7; maxLines = 18
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("▶  EXECUTAR NO LUAU LOCAL", red) {
            status.text = "Executando..."
            console.text = try { runLuau(editor.text.toString()) } catch (e: Exception) { "Erro no runtime: ${e.message}" }
            status.text = "Execução finalizada"
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(editor.windowToken, 0)
        }, fullParams())
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("Limpar", panel) { editor.setText(""); status.text = "Editor limpo" }, weightParams())
        actions.addView(button("Copiar", panel) {
            val cb = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cb.setPrimaryClip(ClipData.newPlainText("Luau", editor.text.toString()))
            status.text = "Código copiado"
        }, weightParams())
        actions.addView(button("Salvar", panel) { saveInternal() }, weightParams())
        actions.addView(button("Importar", panel) { openFile.launch(arrayOf("text/*", "application/octet-stream")) }, weightParams())
        root.addView(actions)
        root.addView(button("Exportar para arquivo…", panel) { pendingText = editor.text.toString(); createFile.launch(currentFile?.name ?: "script.lua") }, fullParams())
        root.addView(TextView(this).apply { text = "CONSOLE"; setTextColor(red); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setPadding(0,10,0,4) })
        console = TextView(this).apply {
            text = "Pronto. Execute um script para ver a saída."; setTextColor(Color.rgb(100, 255, 140))
            typeface = Typeface.MONOSPACE; textSize = 12f; setPadding(10,10,10,10); setBackgroundColor(Color.BLACK)
        }
        root.addView(ScrollView(this).apply { addView(console) }, LinearLayout.LayoutParams(-1, 92))
        status = TextView(this).apply { text = "Pronto • sem conexão com Roblox"; setTextColor(fg); textSize = 11f; setPadding(0,7,0,0) }
        root.addView(status)
        setContentView(root)
    }

    private fun saveInternal() {
        val dir = File(filesDir, "scripts")
        if (!dir.exists()) dir.mkdirs()
        val name = currentFile?.name ?: "script_${System.currentTimeMillis()}.lua"
        val file = File(dir, safeName(name))
        try {
            file.writeText(editor.text.toString())
            currentFile = file
            status.text = "Salvo: ${file.name}"
        } catch (e: Exception) { log("Erro ao salvar: ${e.message}") }
    }

    private fun showFiles() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,16); setBackgroundColor(bg) }
        page.addView(TextView(this).apply { text = "MEUS SCRIPTS"; textSize = 22f; setTextColor(red); typeface = Typeface.DEFAULT_BOLD })
        page.addView(button("＋ Novo script", red) {
            currentFile = null; showEditor(); editor.setText("-- Novo script Luau\n")
        }, fullParams())
        page.addView(button("Importar arquivo do dispositivo", panel) { openFile.launch(arrayOf("text/*", "application/octet-stream")) }, fullParams())
        val dir = File(filesDir, "scripts")
        if (!dir.exists()) dir.mkdirs()
        val list = dir.listFiles()?.sortedBy { it.name } ?: emptyList()
        if (list.isEmpty()) page.addView(TextView(this).apply { text = "Nenhum script salvo ainda."; setTextColor(fg); setPadding(0,16,0,16) })
        list.forEach { file ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(button(file.name, panel) {
                try { currentFile = file; showEditor(); editor.setText(file.readText()); status.text = "Aberto: ${file.name}" }
                catch (e: Exception) { Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_SHORT).show() }
            }, LinearLayout.LayoutParams(0, 50, 1f))
            row.addView(button("Renomear", panel) {
                val input = EditText(this).apply { setText(file.nameWithoutExtension); setSingleLine() }
                android.app.AlertDialog.Builder(this).setTitle("Novo nome").setView(input)
                    .setPositiveButton("Salvar") { _, _ ->
                        val target = File(dir, safeName(input.text.toString()) + ".lua")
                        if (target.exists()) Toast.makeText(this, "Já existe um arquivo com esse nome", Toast.LENGTH_SHORT).show()
                        else if (file.renameTo(target)) showFiles() else Toast.makeText(this, "Não foi possível renomear", Toast.LENGTH_SHORT).show()
                    }.setNegativeButton("Cancelar", null).show()
            })
            row.addView(button("Excluir", panel) {
                android.app.AlertDialog.Builder(this).setTitle("Excluir ${file.name}?")
                    .setMessage("Esta ação não pode ser desfeita.")
                    .setPositiveButton("Excluir") { _, _ -> file.delete(); if (currentFile == file) currentFile = null; showFiles() }
                    .setNegativeButton("Cancelar", null).show()
            })
            page.addView(row)
        }
        page.addView(button("← Voltar ao editor", red) { showEditor() }, fullParams())
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun showSettings() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,18,18,18); setBackgroundColor(bg) }
        page.addView(TextView(this).apply { text = "CONFIGURAÇÕES"; textSize = 22f; setTextColor(red); typeface = Typeface.DEFAULT_BOLD })
        page.addView(button("Alternar tema claro/escuro", panel) { dark = !dark; showSettings() }, fullParams())
        page.addView(TextView(this).apply { text = "Idioma: Português (Brasil)"; textSize = 16f; setTextColor(fg); setPadding(0,12,0,12) })
        page.addView(TextView(this).apply {
            text = "Roblox MOD BR 1.2\nEditor Luau local, sem key.\nNão se conecta nem injeta scripts no Roblox.\nRuntime isolado para testes autorizados."
            textSize = 14f; setTextColor(fg); setPadding(0,12,0,20)
        })
        page.addView(button("← Voltar ao editor", red) { showEditor() }, fullParams())
        setContentView(page)
    }

    private fun safeName(s: String): String {
        val cleaned = s.replace(Regex("[^A-Za-z0-9._-]"), "_").take(48).trim('.')
        return if (cleaned.isBlank()) "script.lua" else if (cleaned.endsWith(".lua")) cleaned else "$cleaned.lua"
    }
    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
        textSize = 12f; isAllCaps = false; setOnClickListener { action() }
    }
    private fun fullParams() = LinearLayout.LayoutParams(-1, 48).apply { topMargin = 6; bottomMargin = 4 }
    private fun weightParams() = LinearLayout.LayoutParams(0, 46, 1f).apply { setMargins(2,2,2,2) }
    private fun log(s: String) { console.text = s }
    private fun writeUri(uri: Uri, value: String) {
        try { contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(value) }; status.text = "Exportado" }
        catch (e: Exception) { log("Erro ao exportar: ${e.message}") }
    }
}
