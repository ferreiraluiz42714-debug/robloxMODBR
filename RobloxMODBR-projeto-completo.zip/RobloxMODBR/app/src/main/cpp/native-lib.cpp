#include <jni.h>
#include <string>
#include <sstream>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "Luau/Compiler.h"

static std::string output;
static void printCallback(lua_State* L, int n) {
    std::ostringstream line;
    for (int i=1;i<=n;i++) {
        size_t len=0; const char* s=luaL_tolstring(L,i,&len);
        if (i>1) line << "\\t";
        if (s) line.write(s, (std::streamsize)len);
        lua_pop(L,1);
    }
    output += line.str() + "\\n";
}
static int nativePrint(lua_State* L) {
    printCallback(L, lua_gettop(L)); return 0;
}
extern "C" JNIEXPORT jstring JNICALL
Java_br_deltamobile_MainActivity_runLuau(JNIEnv* env, jobject, jstring input) {
    const char* src=env->GetStringUTFChars(input, nullptr);
    std::string code(src ? src : "");
    env->ReleaseStringUTFChars(input, src);
    output.clear();
    lua_State* L=luaL_newstate();
    if (!L) return env->NewStringUTF("ERRO: não foi possível criar o runtime.");
    luaL_openlibs(L);
    // Runtime local restrito: sem APIs de sistema, arquivos, módulos ou depuração.
    const char* blocked[]={"io","os","package","debug","require","dofile","loadfile",nullptr};
    for (int i=0; blocked[i]; ++i) { lua_pushnil(L); lua_setglobal(L, blocked[i]); }
    lua_pushcfunction(L, nativePrint, "print"); lua_setglobal(L,"print");
    try {
        Luau::CompileOptions options;
        std::string bytecode=Luau::compile(code, options);
        int loadResult=luau_load(L, "editor", bytecode.data(), bytecode.size(), 0);
        if (loadResult != 0) {
            size_t len=0; const char* err=lua_tolstring(L,-1,&len);
            output += "ERRO DE COMPILAÇÃO: " + std::string(err ? err : "erro desconhecido", len) + "\\n";
        } else {
            int result=lua_pcall(L,0,0,0);
            if (result != 0) {
                size_t len=0; const char* err=lua_tolstring(L,-1,&len);
                output += "ERRO DE EXECUÇÃO: " + std::string(err ? err : "erro desconhecido", len) + "\\n";
            } else if (output.empty()) output = "Execução concluída sem saída.\\n";
        }
    } catch (const std::exception& e) {
        output += std::string("ERRO: ") + e.what() + "\\n";
    }
    lua_close(L);
    return env->NewStringUTF(output.c_str());
}
