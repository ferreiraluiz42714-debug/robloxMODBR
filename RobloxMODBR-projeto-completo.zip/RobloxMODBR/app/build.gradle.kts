plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "br.deltamobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.deltamobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
        externalNativeBuild { cmake { cppFlags += "-std=c++17" } }
    }
    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" }
    }
}
dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
}
